import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { translations } from './translation-map.mjs';
const require=createRequire(import.meta.url);
const {load}=require('cheerio');
const source=path.resolve('content/ru');
const output=path.resolve('dist');
const cyrillic=/[А-Яа-яЁё]/;
const unknown=new Map();
function renderText(value) {
  const normalized=value.replace(/\s+/g,' ').trim();
  if(!cyrillic.test(normalized))return value;
  const translated=translations.get(normalized);
  if(!translated){unknown.set(normalized,(unknown.get(normalized)||0)+1);return value;}
  return value.replace(/\S[\s\S]*\S|\S/,translated);
}
function pageRoute(file) {
  const relative=path.relative(source,file).replaceAll(path.sep,'/');
  return relative==='index.html'?'/':'/'+relative.replace(/index\.html$/,'');
}
function localizedRoute(route,locale) {return locale==='ru'?(route==='/'?'/ru/':'/ru'+route):route;}
function build(file,locale) {
  const route=pageRoute(file);
  const $=load(fs.readFileSync(file,'utf8'),{decodeEntities:false});
  $('html').attr('lang',locale);
  if(locale==='en'){
    $('body').find('*').contents().each((_,node)=>{
      if(node.type==='text'&&!$(node).parents('script,style,svg').length)node.data=renderText(node.data);
    });
    $('title').each((_,node)=>{node.children.forEach(child=>{if(child.type==='text')child.data=renderText(child.data);});});
    $('meta[name="description"]').each((_,node)=>{node.attribs.content=renderText(node.attribs.content||'');});
    $('*').each((_,node)=>{for(const key of ['alt','aria-label','title','placeholder'])if(node.attribs?.[key])node.attribs[key]=renderText(node.attribs[key]);});
    $('script:not([src])').each((_,node)=>{
      let code=$(node).html();
      for(const [ru,en] of [['Пауза','Pause'],['Повторить запуск','Try again'],['Продолжить','Resume'],['Смотреть ещё раз','Watch again']])code=code.replaceAll("label.textContent='"+ru+"'","label.textContent='"+en+"'");
      $(node).html(code);
    });
    if(route==='/')$('.manifesto h2').html('From newcomer<br>to <em>belonging.</em>');
    if(route==='/events/')$('.next-event h2').html('Bridge to <em>Style.</em>');
    if(route==='/community/')$('.community-members-head h2').html('People of <em>The Bridge.</em>');
    if(route==='/speakers/')$('.voices-hero h1').html('Voices of <em>The Bridge.</em>');
  } else {
    $('a[href^="/"]').each((_,node)=>{const href=node.attribs.href;if(!href.startsWith('/ru/')&&!href.startsWith('/assets/')&&!href.startsWith('/_next/'))node.attribs.href=localizedRoute(href,'ru');});
  }
  const nav=$('.nav-wrap').first();
  if(nav.length){
    const switcher=$('<nav class="language-switch" aria-label="'+(locale==='ru'?'Язык сайта':'Site language')+'"><a lang="en" hreflang="en" href="'+localizedRoute(route,'en')+'"'+(locale==='en'?' aria-current="page"':'')+'>EN</a><span aria-hidden="true">/</span><a lang="ru" hreflang="ru" href="'+localizedRoute(route,'ru')+'"'+(locale==='ru'?' aria-current="page"':'')+'>RU</a></nav>');
    const mobile=nav.find('.mobile-site-nav');
    if(mobile.length)mobile.before(switcher);else nav.append(switcher);
  }
  $('head').append('<link rel="alternate" hreflang="en" href="'+localizedRoute(route,'en')+'"><link rel="alternate" hreflang="ru" href="'+localizedRoute(route,'ru')+'">');
  const destination=path.join(output,locale==='ru'?'ru':'',path.relative(source,file));
  fs.mkdirSync(path.dirname(destination),{recursive:true});
  fs.writeFileSync(destination,$.html());
}
function walk(dir){
  for(const item of fs.readdirSync(dir,{withFileTypes:true})){
    const file=path.join(dir,item.name);
    if(item.isDirectory())walk(file);else if(item.name==='index.html'){build(file,'en');build(file,'ru');}
  }
}
walk(source);
if(unknown.size){
  console.error('Untranslated strings:');
  for(const [text,count]of unknown)console.error(count+' × '+text);
  process.exitCode=1;
}else console.log('Built English and Russian versions of every page.');
