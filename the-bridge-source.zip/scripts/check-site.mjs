import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root = path.resolve('dist');
const htmlFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, {withFileTypes:true})) {
    const file=path.join(dir,entry.name);
    if(entry.isDirectory()) walk(file);
    else if(file.endsWith('.html')) htmlFiles.push(file);
  }
}
walk(root);
const missing=[];
for(const file of htmlFiles) {
  const html=fs.readFileSync(file,'utf8');
  for(const [,url] of html.matchAll(/(?:href|src|poster)="([^"]+)"/g)) {
    if(!url.startsWith('/') || url.startsWith('//')) continue;
    const local=path.join(root,decodeURIComponent(url.split(/[?#]/)[0]));
    if(!fs.existsSync(local) && !fs.existsSync(path.join(local,'index.html'))) missing.push(`${path.relative(root,file)}: ${url}`);
  }
}
assert.deepEqual(missing, [], 'Missing local destinations/assets');
const home=fs.readFileSync(path.join(root,'index.html'),'utf8');
assert.equal((home.match(/class="hero-action /g)||[]).length,2,'Exactly two primary hero actions');
const videoTag=home.match(/<video\b[^>]*>/)?.[0] || '';
for(const flag of ['autoplay','muted','loop','playsinline'])assert.match(videoTag,new RegExp('\\b'+flag+'(?:=|\\s|>)'),`Hero video must have ${flag}`);
assert.doesNotMatch(home, /class="hero-play/);
for(const file of ['community-background.mp4','community-background-mobile.mp4']) {
  const data=fs.readFileSync(path.join(root,'assets/video',file));
  assert.ok(data.indexOf(Buffer.from('moov'))<data.indexOf(Buffer.from('mdat')),`${file} must support fast start`);
  assert.ok(!data.includes(Buffer.from('soun')),`${file} must not contain an audio handler`);
}
console.log(`PASS: ${htmlFiles.length} routes, all local links/assets, two hero CTAs, autoplay markup and silent fast-start media.`);
