// Static renderer: shared editable JSON; no dependency on a browser or framework.
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('content/ru');
const people = JSON.parse(fs.readFileSync(path.resolve('dist/data/people.json'),'utf8'));
const esc = s => String(s || '').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;');
function image(p) {
  const supplied = p.image.startsWith('/assets/people/');
  return '<img src="'+esc(p.image)+'"'+(supplied ? ' srcset="'+esc(p.image.replace('.webp','-480.webp'))+' 480w, '+esc(p.image)+' '+p.width+'w" sizes="(min-width:1100px) 23vw, (min-width:600px) 44vw, 90vw"' : '')+' alt="'+esc(p.name)+'" width="'+p.width+'" height="'+p.height+'" loading="lazy" decoding="async" style="object-position:'+(p.position || '50% 30%')+'">';
}
function card(p, community=false) {
  const href=community?'/speakers/#'+p.id:'#profile-'+p.id;
  const trigger=community?'':' data-profile="'+p.id+'"';
  return '<article class="person-card" id="'+(community?'member-':'')+p.id+'" data-categories="'+esc(p.categories.join('|'))+'">'+
    '<a class="person-photo" href="'+href+'"'+trigger+' aria-label="Открыть профиль: '+esc(p.name)+'">'+image(p)+'</a>'+
    '<div class="person-copy"><h3>'+esc(p.name)+'</h3>'+
    (p.description?'<p class="person-description">'+esc(p.description)+'</p>':'')+
    (p.location?'<p class="person-location">'+esc(p.location)+'</p>':'')+
    (p.categories.length?'<ul class="person-tags" aria-label="Темы">'+p.categories.map(c=>'<li>'+esc(c)+'</li>').join('')+'</ul>':'')+
    '<a class="person-more" href="'+href+'"'+trigger+'>Узнать больше <span aria-hidden="true">↗</span></a></div></article>';
}
function profile(p) {
  return '<details class="person-profile" id="profile-'+p.id+'"><summary>'+esc(p.name)+'</summary><div class="profile-content">'+
    image(p)+'<div class="profile-text"><h2>'+esc(p.name)+'</h2>'+
    (p.facts.length?'<dl>'+p.facts.map(f=>'<div><dt>'+esc(f.label)+'</dt><dd>'+esc(f.value)+'</dd></div>').join('')+'</dl>':'')+
    (p.link?'<a class="text-link" href="'+esc(p.link)+'" target="_blank" rel="noreferrer">Публичный канал ↗</a>':'')+
    '<a class="text-link" href="'+esc(p.image)+'" target="_blank" rel="noreferrer">Открыть фотографию ↗</a></div></div></details>';
}
let speakers=fs.readFileSync(path.join(root,'speakers/index.html'),'utf8');
const start=speakers.indexOf('  <section class="page-hero');
const end=speakers.indexOf('  <section class="conversation-rules');
const categories=[...new Set(people.flatMap(p=>p.categories))];
speakers=speakers.slice(0,start)+'  <section class="page-hero voices-hero">'+
 '<p class="section-kicker">THE BRIDGE / VOICES</p><h1>Голоса <em>The Bridge.</em></h1>'+
 '<p>Люди, с которыми стоит познакомиться. Идеи, которыми стоит делиться.</p>'+
 '<p class="voices-intro">Спикеры, сооснователи и герои сообщества. Их опыт превращает встречу в честный разговор, который продолжается и после события.</p></section>'+
 '<section class="people-directory section-pad" aria-label="Каталог людей">'+
 '<div class="people-toolbar"><div class="people-filters" hidden aria-label="Фильтр по темам">'+
 ['Все',...categories].map((c,i)=>'<button type="button" data-category="'+(i?esc(c):'all')+'" aria-pressed="'+(!i)+'">'+esc(c)+'</button>').join('')+
 '</div><p class="people-count" role="status" aria-live="polite">'+people.length+' голосов</p></div>'+
 '<div class="people-grid">'+people.map(p=>card(p)).join('\n')+'</div>'+
 '<div class="people-profiles" aria-label="Подробные профили">'+people.map(profile).join('\n')+'</div></section>'+
 '<dialog class="person-dialog" aria-labelledby="dialog-person-name"><button class="dialog-close" type="button" aria-label="Закрыть профиль">✕</button><div class="dialog-body"></div></dialog>\n'+speakers.slice(end);
fs.writeFileSync(path.join(root,'speakers/index.html'),speakers);
let community=fs.readFileSync(path.join(root,'community/index.html'),'utf8');
community=community.replace(/<img[^>]*src="\/assets\/bridge\/11-1536x1152.webp"[^>]*>/,'<img src="/assets/community/drinks-conversation.webp" srcset="/assets/community/drinks-conversation-640.webp 640w, /assets/community/drinks-conversation.webp 1280w" sizes="(min-width:851px) 50vw, 100vw" width="1280" height="854" alt="Участники The Bridge общаются за столом с напитками" loading="lazy" decoding="async">');
const gridStart=community.indexOf('    <div class="community-member-grid')>=0?community.indexOf('    <div class="community-member-grid'):community.indexOf('    <div class="people-grid community-people-grid');
if(gridStart>=0){
 const gridEnd=community.indexOf('  </section>',gridStart);
 community=community.slice(0,gridStart)+'    <div class="people-grid community-people-grid">'+
 ['timur-beslangurov','sasha-meets-russia','tatiana-klimova','guy-eames'].map(id=>card(people.find(p=>p.id===id),true)).join('\n')+'</div>\n'+community.slice(gridEnd);
}
fs.writeFileSync(path.join(root,'community/index.html'),community);
function walk(dir){
 for(const e of fs.readdirSync(dir,{withFileTypes:true})){
  const file=path.join(dir,e.name);
  if(e.isDirectory()) walk(file);
  else if(file.endsWith('.html')){
   let html=fs.readFileSync(file,'utf8');
   html=html.replace('<script src="/motion.js" defer></script>','');
   if(!html.includes('/editorial.css')) html=html.replace('</head>','<link rel="stylesheet" href="/editorial.css?v=20260925"/>\n</head>');
   if(!html.includes('/editorial.js')) html=html.replace('</body>','<script src="/editorial.js?v=20260925" defer></script></body>');
   html=html.replace('<summary>Меню</summary>','<summary aria-label="Открыть меню">Меню</summary>');
   fs.writeFileSync(file,html);
  }
 }
}
walk(root);
console.log('Rendered 10 people from shared JSON and updated all public pages.');
