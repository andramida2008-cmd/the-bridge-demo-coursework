# The Bridge demo — editable copy

This is a self-contained, static and editable copy of the published The Bridge demo.

- Edit any page at `dist/<route>/index.html`.
- Edit global design in `dist/_next/static/css/index.B7RH2MYQ.css` and clone-specific responsive navigation in `dist/clone-controls.css`.
- Local Bridge photos are stored under `dist/assets/bridge/`.
- The original app scripts were deliberately removed so internal links behave as ordinary, reliable multi-page navigation in this editable static version.

## Homepage — September 2026

- Homepage-only styling: `dist/homepage.css`; native background playback: `dist/hero-background.js`.
- Two primary actions lead to the existing Telegram community and the next event at https://the-bridge-club.timepad.ru/event/4203382/ (1 October, 18:30). Update the registration link and event note together when the next event changes.
- Background video uses the supplied `bridge-hero.mp4` report, trimmed to community conversations, audience and speakers (29–43s, 24–28s, 54–60s). Desktop/mobile outputs are 24s, H.264, 30fps, with no audio stream and fast-start metadata. They use native autoplay, muted, loop and playsinline, with no timers or forced seeking.
- Browsers that disallow autoplay retain the event photograph. A discreet pause control is available once playback starts. Offscreen/background-tab playback pauses to conserve resources and resumes without restarting the timeline.
- New photographs are from the user-provided album: https://podolyakinandrew.gallery.photo/gallery/bridge-to-belonging-gp4es9 . The original photographs and routes elsewhere are preserved.

### Photograph provenance

All four source images share this prefix: `https://storage.vigbo.tech/p/w1920/gallery-photo/96bd9ab7-9d8a-47ff-b218-d019bd814fac/0a5c66ea-97bd-4976-84db-6b6a6393ad28/original/`.

| Local file under `dist/assets/community/` | Source filename |
| --- | --- |
| gathering.jpg (poster) | VUzHrggK0GPM7CqhJIUZC.jpg |
| conversation.jpg | z_lHW2Oqb0v7uGbe_1er-.jpg |
| audience.jpg | Ul4L2T6ie1lP4vsZmrNvX.jpg |
| speaker.jpg | YDGzCBprSeDsl1qGMxqnj.jpg |
